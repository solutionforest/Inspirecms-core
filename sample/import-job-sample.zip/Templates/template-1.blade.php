<div>
    <h1>Sample View</h1>
    <p>This is a sample view.</p>
</div>