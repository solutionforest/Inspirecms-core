<div>
    <h1>Sample View 2</h1>
    <p>This is a sample view.</p>
</div>