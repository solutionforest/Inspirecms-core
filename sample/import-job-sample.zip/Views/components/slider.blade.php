<div class="sample-view">
    <!-- sample view content -->
</div>

